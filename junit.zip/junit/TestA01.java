public class TestA01 {

  public static void main(String[] args) {
      TestUtils.runClass(TestTicTacToe.class);
  }

}
