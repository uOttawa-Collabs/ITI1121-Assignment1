public class TestA04 {

  public static void main(String[] args) {

    // These tests you need to make work
    TestUtils.runClass(TestMenaceGame.class);
    TestUtils.runClass(TestComputerMenacePlayer.class);

    // These tests helped me write the code
    // TestUtils.runClass(TestGameOutcome.class);
    // TestUtils.runClass(TestTrackWinsLosesDraws.class);
    // TestUtils.runClass(TestOpenPositionsOnRotatedGame.class);
    // TestUtils.runClass(TestPerfectGame.class);
    // TestUtils.runClass(TestComputerPerfectPlayer.class);
    // TestUtils.runClass(TestCloneUndo.class);

  }

}
